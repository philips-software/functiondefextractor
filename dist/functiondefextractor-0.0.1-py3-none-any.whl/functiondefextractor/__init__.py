"""Koninklijke Philips N.V., 2019 - 2020. All rights reserved."""
